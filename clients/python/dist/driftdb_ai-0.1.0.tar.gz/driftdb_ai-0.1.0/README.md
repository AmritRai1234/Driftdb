# DriftDB Python Client

**The AI-native database client.** Graph memory + vector search + real-time sync in 5.3 MB.

```bash
pip install driftdb
```

## Quick Start

```python
from driftdb import DriftDB

db = DriftDB("http://localhost:9211", token="your-token")

# Create nodes
db.create_node(labels=["User"], properties={"name": "Amrit", "age": 25})

# Query with DriftQL
result = db.query('FIND (u:User) RETURN u.name, u.age')

# AI Memory — one line to give your LLM a brain
db.remember("User prefers dark mode")
db.remember("Meeting at 3pm tomorrow", labels=["Event"])

# Recall via vector similarity
db.recall(vector=[0.1, 0.5, 0.9], limit=5)

# Vector similarity search
db.similar([0.1, 0.5, 0.9, 0.3], threshold=0.8, limit=10)

# Statistics
db.stats()
```

## API

| Method | Description |
|---|---|
| `DriftDB(url, token)` | Connect to DriftDB |
| `db.query(driftql)` | Execute DriftQL query |
| `db.create_node(labels, properties)` | Create a node |
| `db.get_node(id)` | Get node by ID |
| `db.list_nodes()` | List all nodes |
| `db.delete_node(id)` | Soft-delete node |
| `db.find(label, where_clause, returns)` | Find by label |
| `db.create_edge(src, tgt, type, props)` | Create edge |
| `db.remember(text, labels, vector)` | Store AI memory |
| `db.recall(text, vector, limit)` | Recall memories |
| `db.similar(vector, threshold, limit)` | Vector similarity |
| `db.backup(directory, password)` | Backup database |
| `db.health()` / `db.is_healthy()` | Health check |
| `db.stats()` | Database stats |

## Requirements

- Python 3.8+
- A running DriftDB server (`driftdb --serve --rest`)

## License

SSPL-1.0 (same as MongoDB)

[GitHub](https://github.com/AmritRai1234/Driftdb) · [Documentation](https://github.com/AmritRai1234/Driftdb/blob/main/DOCS.md)
